package bitcamp;

public class EmployeeMain {
    public static void main(String[] args) {
        EmployeeService employeeService = new EmployeeService();
        employeeService.menu();
        System.out.println("프로그램을 종료합니다.");
    }
}
