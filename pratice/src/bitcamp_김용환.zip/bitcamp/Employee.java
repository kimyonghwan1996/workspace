package bitcamp;

import java.util.ArrayList;

public interface Employee {
    public void execute(ArrayList<EmployeeDTO> list);
}
